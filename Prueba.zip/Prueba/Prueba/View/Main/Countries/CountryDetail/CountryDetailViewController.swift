//
//  CountryDetailViewController.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import UIKit
import SDWebImage

class CountryDetailViewController: UIViewController {

    @IBOutlet weak var countryNameLabel: UILabel!
    @IBOutlet weak var countryRegionLabel: UILabel!
    @IBOutlet weak var countryCapitalLabel: UILabel!
    @IBOutlet weak var countryPopulationLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var countryImage: UIImageView!
    
    var viewModel: CountryViewModel = CountryViewModel()
    var country: Country?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        setupView()
    }

    @IBAction func dissmissAction(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func setupView() {
        self.countryNameLabel.text = country?.name
        self.countryRegionLabel.text = country?.region
        self.countryCapitalLabel.text = country?.capital
        self.countryPopulationLabel.text = "\(country?.population!)"
        self.countryImage.sd_setImage(with: URL(string: "https://www.countryflags.io/\(country?.flag!)/flat/64.png"), placeholderImage: nil, options: SDWebImageOptions.highPriority, completed: nil)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
