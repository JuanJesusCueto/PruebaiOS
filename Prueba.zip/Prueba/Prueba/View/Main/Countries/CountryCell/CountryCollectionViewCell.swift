//
//  CountryCollectionViewCell.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import UIKit
import SDWebImage

class CountryCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var countryImageView: UIImageView!
    @IBOutlet weak var countryLabel: UILabel!
    @IBOutlet weak var favoriteButton: UIButton!
    @IBOutlet weak var containerView: UIView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    func setupView(with country: Country) {
        self.countryLabel.text = country.name
        
        if let url: URL = URL(string: "https://www.countryflags.io/\(country.flag!)/flat/64.png") {
            self.countryImageView.sd_setImage(with: url, placeholderImage: nil, options: SDWebImageOptions.highPriority, completed: nil)
        }
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.containerView.layer.cornerRadius = 12.0
    }
}
