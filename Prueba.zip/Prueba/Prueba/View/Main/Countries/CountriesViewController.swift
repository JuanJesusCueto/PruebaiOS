//
//  CountriesViewController.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import UIKit

class CountriesViewController: UIViewController {

    @IBOutlet weak var collectionView: UICollectionView!
    
    var countriesList: [Country]!
    var viewModel: CountryViewModel = CountryViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        self.collectionView.register(UINib(nibName: "CountryCollectionViewCell", bundle: nil), forCellWithReuseIdentifier: "countryCell")
        
        self.loadData()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func loadData() {
        viewModel.getCountries(success: { (list) in
            self.countriesList = list
            self.collectionView.reloadData()
        }) { (message) in
            print(message)
        }
    }

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showDescription" {
            if let vc = segue.destination as? CountryDetailViewController {
                if let index = sender as? Int {
                    vc.country = countriesList[index]
                }
            }
        }
    }
 

}

extension CountriesViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        self.performSegue(withIdentifier: "showDescription", sender: indexPath.row)
    }
}

extension CountriesViewController: UICollectionViewDataSource {
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if countriesList != nil {
            return countriesList.count
        } else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "countryCell", for: indexPath) as? CountryCollectionViewCell
        
        cell?.setupView(with: countriesList[indexPath.row])
        
        return cell!
    }
}

extension CountriesViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = self.collectionView.bounds.width - 40.0
        let height = self.collectionView.bounds.height / 3.0
        
        return CGSize(width: width, height: height)
    }
}
