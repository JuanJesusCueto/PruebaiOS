//
//  CountryApi.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import Foundation

class CountryApi {
    static let getCountryURL: String = "https://restcountries.eu/rest/v2/all"
}
