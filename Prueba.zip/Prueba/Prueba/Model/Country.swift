//
//  Country.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import Foundation
import SwiftyJSON

class Country {
    var name: String?
    var capital: String?
    var region: String?
    var population: Int?
    var flag: String?
    
    init(name: String, capital: String, region: String, population: Int, flag: String) {
        self.name = name
        self.capital = capital
        self.region = region
        self.population = population
        self.flag = flag
    }
    
    init(from object: JSON){
        if let name = object["name"].string {
            self.name = name
        }
        if let capital = object["capital"].string {
            self.capital = capital
        }
        if let region = object["region"].string {
            self.region = region
        }
        if let population = object["population"].int {
            self.population = population
        }
        if let flag = object["alpha2Code"].string {
            self.flag = flag
        }
    }
    
    static func from(jsonCountries: [JSON]) -> [Country] {
        
        var countries: [Country] = []
        
        for country in jsonCountries {
            countries.append(Country.init(from: country))
        }
        return countries
    }
}
