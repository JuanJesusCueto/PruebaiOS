//
//  CountryViewModel.swift
//  Prueba
//
//  Created by Jesus Cueto on 8/17/18.
//  Copyright © 2018 Jesus Cueto. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class CountryViewModel {
    
    init() {
    }
    
    func getCountries(success: @escaping ([Country]) -> Void, failure: @escaping (String) -> Void) {
        Alamofire.request(CountryApi.getCountryURL, method: .get, parameters: nil, encoding: URLEncoding.default, headers: nil).responseJSON { (jsonData) in
            let statusCode = jsonData.response?.statusCode
            print("\(statusCode!)")
            
            switch jsonData.result {
            case .success(let value):
                let jsonObject = JSON(value)
                let countriesList = Country.from(jsonCountries: jsonObject.arrayValue)
                success(countriesList)
            case .failure(let error):
                failure(error.localizedDescription)
            }
        }
    }
}
